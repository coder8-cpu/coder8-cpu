﻿Imports System
Imports System.ComponentModel
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Imports OfficeOpenXml

Public Class Form1
    'inherating the main form class to create the empty form
    Inherits Form

    'declaring crontrollers on private variable 
    Private DataGridView1 As DataGridView
    Private txtName As TextBox
    Private txtMobile As TextBox
    Private txtGoldPrice As TextBox
    Private txtQuantity As TextBox
    Private txtAmountPaid As TextBox
    Private txtDueAmount As TextBox
    Private txtGoldDueQty As TextBox
    Private btnSubmit As Button
    Private txtSearch As TextBox
    Private lblSearch As Label
    'database path as public variable 
    Public excelPath As String = "database.xlsx"
    Private dt As New DataTable()

    Public Sub New()
        'this subroutine is responsible for creating the form and setting up its attribute
        Me.Text = "Gold Transactions"
        Me.Size = New Drawing.Size(1000, 600)
        Me.StartPosition = FormStartPosition.CenterScreen

        'intializing over form 
        InitializeControls()
    End Sub


    'handles controls and its behaviour of apperiance
    Private Sub InitializeControls()
        ' define table 
        DataGridView1 = New DataGridView()
        DataGridView1.Location = New Drawing.Point(20, 20)
        DataGridView1.Size = New Drawing.Size(940, 200)
        DataGridView1.ReadOnly = True
        DataGridView1.AllowUserToAddRows = False
        Me.Controls.Add(DataGridView1)


        ' define search box
        txtSearch = New TextBox()
        txtSearch.Location = New Drawing.Point(150, 225)
        txtSearch.Width = 200
        ' define the handler event which handles the search input while event occure text changed
        AddHandler txtSearch.TextChanged, AddressOf txtSearch_TextChanged
        Me.Controls.Add(txtSearch)

        txtName = New TextBox()
        txtName.Location = New Drawing.Point(20, 270)
        txtName.Width = 200

        Me.Controls.Add(txtName)


        txtMobile = New TextBox()
        txtMobile.Location = New Drawing.Point(240, 270)
        txtMobile.Width = 200

        Me.Controls.Add(txtMobile)






        txtName = New TextBox()
        txtName.Location = New Drawing.Point(20, 310)
        txtName.Width = 200
        txtName.Text = "Gold Price"
        Me.Controls.Add(txtName)
        txtMobile = New TextBox()
        txtMobile.Location = New Drawing.Point(240, 310)
        txtMobile.Width = 200
        txtMobile.Text = "Gold Price"
        Me.Controls.Add(txtMobile)




        txtGoldPrice = New TextBox()
        txtGoldPrice.Location = New Drawing.Point(20, 310)
        txtGoldPrice.Width = 200
        txtGoldPrice.Text = "Gold Price"
        Me.Controls.Add(txtGoldPrice)

        txtQuantity = New TextBox()
        txtQuantity.Location = New Drawing.Point(240, 310)
        txtQuantity.Width = 200
        txtQuantity.Text = "Quantity"
        Me.Controls.Add(txtQuantity)


        txtAmountPaid = New TextBox()
        txtAmountPaid.Location = New Drawing.Point(20, 350)
        txtAmountPaid.Width = 200
        txtAmountPaid.Text = "Amount Paid"
        Me.Controls.Add(txtAmountPaid)

        txtDueAmount = New TextBox()
        txtDueAmount.Location = New Drawing.Point(240, 350)
        txtDueAmount.Width = 200
        txtDueAmount.Text = "Due Amount"
        txtDueAmount.ReadOnly = True
        Me.Controls.Add(txtDueAmount)


        txtGoldDueQty = New TextBox()
        txtGoldDueQty.Location = New Drawing.Point(20, 390)
        txtGoldDueQty.Width = 200
        txtGoldDueQty.Text = "Gold Due Qty"
        txtGoldDueQty.ReadOnly = True
        Me.Controls.Add(txtGoldDueQty)

        btnSubmit = New Button()
        btnSubmit.Text = "Submit"
        btnSubmit.Location = New Drawing.Point(240, 390)
        btnSubmit.Width = 200
        AddHandler btnSubmit.Click, AddressOf btnSubmit_Click
        Me.Controls.Add(btnSubmit)


        AddHandler Me.Load, AddressOf Form1_Load
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs)
        'ExcelPackage.LicenseContext = LicenseContext.NonCommercial

        If Not File.Exists(excelPath) Then
            CreateExcelFile()
        End If

        LoadData()
        SetupAutoComplete()
    End Sub

    ' Create Excel if not exists
    Private Sub CreateExcelFile()
        Using package As New ExcelPackage(New FileInfo(excelPath))
            Dim ws = package.Workbook.Worksheets.Add("Sheet1")

            ws.Cells(1, 1).Value = "Name"
            ws.Cells(1, 2).Value = "Mobile"
            ws.Cells(1, 3).Value = "GoldPrice"
            ws.Cells(1, 4).Value = "Quantity"
            ws.Cells(1, 5).Value = "AmountPaid"
            ws.Cells(1, 6).Value = "DueAmount"
            ws.Cells(1, 7).Value = "GoldDueQuantity"

            package.Save()
        End Using
    End Sub


    Private Sub LoadData()
        dt = New DataTable()
        dt.Columns.AddRange({
            New DataColumn("Name"),
            New DataColumn("Mobile"),
            New DataColumn("GoldPrice"),
            New DataColumn("Quantity"),
            New DataColumn("AmountPaid"),
            New DataColumn("DueAmount"),
            New DataColumn("GoldDueQuantity")
        })

        Using package As New ExcelPackage(New FileInfo(excelPath))
            Dim ws = package.Workbook.Worksheets(1)
            If ws.Dimension IsNot Nothing Then
                Dim rows = ws.Dimension.End.Row

                For i = 2 To rows
                    dt.Rows.Add(ws.Cells(i, 1).Text,
                                ws.Cells(i, 2).Text,
                                ws.Cells(i, 3).Text,
                                ws.Cells(i, 4).Text,
                                ws.Cells(i, 5).Text,
                                ws.Cells(i, 6).Text,
                                ws.Cells(i, 7).Text)
                Next
                Dim goldPrice As Integer = 0
                Dim amountPaid As Integer = 0
                For i = 2 To rows
                    goldPrice = goldPrice + ws.Cells(i, 3).Text
                    amountPaid = amountPaid + ws.Cells(i, 5).Text

                Next
                dt.Rows.Add("none",
                                "none",
                               goldPrice,
                                "none",
                              amountPaid,
                               "none",
                               "none")

            End If
        End Using

        DataGridView1.DataSource = dt
    End Sub


    Private Sub btnSubmit_Click(sender As Object, e As EventArgs)
        Dim goldPrice As Decimal = Decimal.Parse(txtGoldPrice.Text)
        Dim qty As Decimal = Decimal.Parse(txtQuantity.Text)
        Dim paid As Decimal = Decimal.Parse(txtAmountPaid.Text)

        Dim totalAmount As Decimal = goldPrice * qty
        Dim dueAmount As Decimal = totalAmount - paid
        Dim dueQty As Decimal = If(goldPrice > 0, dueAmount / goldPrice, 0)

        txtDueAmount.Text = dueAmount.ToString("0.00")
        txtGoldDueQty.Text = dueQty.ToString("0.00")

        Using package As New ExcelPackage(New FileInfo(excelPath))
            Dim ws = package.Workbook.Worksheets(0)
            Dim newRow = ws.Dimension.End.Row + 1

            ws.Cells(newRow, 1).Value = txtName.Text
            ws.Cells(newRow, 2).Value = txtMobile.Text
            ws.Cells(newRow, 3).Value = goldPrice
            ws.Cells(newRow, 4).Value = qty
            ws.Cells(newRow, 5).Value = paid
            ws.Cells(newRow, 6).Value = dueAmount
            ws.Cells(newRow, 7).Value = dueQty

            package.Save()
        End Using

        LoadData()
        SetupAutoComplete()
        ClearFields()
    End Sub


    Private Sub SetupAutoComplete()
        Dim nameCollection As New AutoCompleteStringCollection()
        Dim mobileCollection As New AutoCompleteStringCollection()

        For Each row As DataRow In dt.Rows
            nameCollection.Add(row("Name").ToString())
            mobileCollection.Add(row("Mobile").ToString())
        Next

        txtName.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        txtName.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtName.AutoCompleteCustomSource = nameCollection

        txtMobile.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        txtMobile.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtMobile.AutoCompleteCustomSource = mobileCollection
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs)
        Dim dv As DataView = dt.DefaultView
        dv.RowFilter = String.Format("Name LIKE '%{0}%'", txtSearch.Text.Replace("'", "''"))
        DataGridView1.DataSource = dv.ToTable()
    End Sub

    Private Sub ClearFields()
        txtName.Clear()
        txtMobile.Clear()
        txtGoldPrice.Clear()
        txtQuantity.Clear()
        txtAmountPaid.Clear()
        txtDueAmount.Clear()
        txtGoldDueQty.Clear()
    End Sub


End Class
